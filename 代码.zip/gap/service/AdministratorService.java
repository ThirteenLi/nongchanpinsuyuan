package com.gap.service;

import com.gap.domain.Administrator;

public interface AdministratorService {
	
	Administrator getAdministratorByNamePassword(Administrator admin);
}
