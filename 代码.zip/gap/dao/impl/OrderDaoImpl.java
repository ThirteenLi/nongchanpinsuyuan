package com.gap.dao.impl;

import com.gap.dao.OrderDao;
import com.gap.domain.Order;



public class OrderDaoImpl extends BaseDaoImpl<Order> implements OrderDao {


}
