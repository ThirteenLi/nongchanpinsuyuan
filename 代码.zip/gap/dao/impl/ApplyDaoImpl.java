package com.gap.dao.impl;

import com.gap.dao.ApplyDao;
import com.gap.domain.Apply;

//申请类型
public class ApplyDaoImpl extends BaseDaoImpl<Apply> implements ApplyDao {

}
