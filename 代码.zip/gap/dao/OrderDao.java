package com.gap.dao;
import com.gap.domain.Order;

public interface OrderDao extends BaseDao<Order>{


	
}
