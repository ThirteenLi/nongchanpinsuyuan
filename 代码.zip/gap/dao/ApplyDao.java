package com.gap.dao;

import com.gap.domain.Apply;

//申请内容
public interface ApplyDao extends BaseDao<Apply> {

}
